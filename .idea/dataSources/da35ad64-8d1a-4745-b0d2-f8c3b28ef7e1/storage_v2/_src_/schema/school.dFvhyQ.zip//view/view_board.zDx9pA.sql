create definer = root@localhost view view_board as
select `b`.`bd_seq`                AS `bd_seq`,
       `b`.`mb_id`                 AS `mb_id`,
       `b`.`bd_title`              AS `bd_title`,
       `b`.`bd_content`            AS `bd_content`,
       `b`.`bd_create_at`          AS `bd_create_at`,
       `b`.`bd_update_at`          AS `bd_update_at`,
       `f`.`up_original_file_name` AS `up_original_file_name`,
       `f`.`up_new_file_name`      AS `up_new_file_name`,
       `f`.`up_file_path`          AS `up_file_path`,
       `f`.`up_file_size`          AS `up_file_size`
from `school`.`board` `b`
         join `school`.`files` `f`
where `b`.`bd_seq` = `f`.`bd_seq`
  and `b`.`mb_id` = `f`.`mb_id`;

